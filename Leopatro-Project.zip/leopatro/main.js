"use strict";
const { app, BrowserWindow, WebContentsView, ipcMain, Menu, session, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const { pathToFileURL, fileURLToPath } = require("url");
const C = require("./config");
const TRACKERS = require("./blocklist");

// ---------- performance & hardening switches (must be set before ready) ----------
app.commandLine.appendSwitch("enable-gpu-rasterization");
app.commandLine.appendSwitch("enable-zero-copy");
app.commandLine.appendSwitch("disable-features", "CalculateNativeWinOcclusion,MediaRouter");
app.enableSandbox();
app.userAgentFallback = app.userAgentFallback.replace(/\s(Electron|leopatro)\/\S+/gi, "");

const TABBAR_H = 42, TOOLBAR_H = 46, BOOKMARK_H = 34, TOP_H = TABBAR_H + TOOLBAR_H + BOOKMARK_H;
const UI_DIR = path.join(__dirname, "ui");
const tabs = new Map(), tabByWc = new Map(), httpAllow = new Set(), decisions = new Map();
let win, activeId = null, nextId = 1, htmlFull = false, settings = { welcomed: false, blocked: 0 };

// ---------- settings ----------
const settingsFile = () => path.join(app.getPath("userData"), "settings.json");
function loadSettings() { try { settings = { ...settings, ...JSON.parse(fs.readFileSync(settingsFile(), "utf8")) }; } catch {} }
let saveT = null;
function saveSoon() { if (saveT) return; saveT = setTimeout(() => { saveT = null; try { fs.writeFileSync(settingsFile(), JSON.stringify(settings)); } catch {} }, 3000); }

// ---------- URLs ----------
const page = (f, q = {}) => {
  const u = pathToFileURL(path.join(UI_DIR, f));
  for (const [k, v] of Object.entries({ creator: C.CREATOR, v: C.VERSION, blocked: settings.blocked, ...q })) u.searchParams.set(k, v);
  return u.href;
};
function toURL(s) {
  s = (s || "").trim();
  if (!s) return page("newtab.html");
  if (/^https?:\/\//i.test(s)) return s;
  if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?(\/|$)/i.test(s)) return "http://" + s;
  if (!/\s/.test(s) && /^[^\s]+\.[^\s.]{2,}(:\d+)?(\/.*)?$/.test(s)) return "https://" + s;
  return C.SEARCH + encodeURIComponent(s);
}
const isLocal = (h) => h === "localhost" || /^(127\.|10\.|192\.168\.)/.test(h) || h.endsWith(".local");
const isTracker = (h) => { for (let p = h; p.includes("."); p = p.slice(p.indexOf(".") + 1)) if (TRACKERS.has(p)) return true; return false; };
function navAllowed(wc, u) {
  try {
    const x = new URL(u);
    if (x.protocol === "https:" || x.protocol === "http:") return true;
    if (x.protocol === "file:") return wc.getURL().startsWith("file:") && fileURLToPath(x).startsWith(UI_DIR);
  } catch {}
  return false;
}

// ---------- tab state (coalesced to avoid lag) ----------
const active = () => tabs.get(activeId);
const activeWC = () => active()?.view.webContents;
let pushT = null;
function push() { if (!pushT) pushT = setTimeout(pushNow, 30); }
function pushNow() {
  if (pushT) { clearTimeout(pushT); pushT = null; }
  if (!win || win.isDestroyed()) return;
  const wc = activeWC();
  win.webContents.send("state", {
    activeId,
    canBack: !!wc?.navigationHistory.canGoBack(),
    canForward: !!wc?.navigationHistory.canGoForward(),
    tabs: [...tabs.values()].map((t) => ({ id: t.id, title: t.title, loading: t.loading, favicon: t.favicon, blocked: t.blocked, url: t.url.startsWith("file:") ? "" : t.url }))
  });
}
let layT = null;
function layoutSoon() { if (!layT) layT = setTimeout(() => { layT = null; layout(); }, 8); }
function layout() {
  const a = active(); if (!a || !win) return;
  const [w, h] = win.getContentSize();
  a.view.setBounds(htmlFull ? { x: 0, y: 0, width: w, height: h } : { x: 0, y: TOP_H, width: w, height: Math.max(0, h - TOP_H) });
}
function activate(id) {
  const next = tabs.get(id); if (!next) return;
  const old = active();
  if (old && old !== next) { try { win.contentView.removeChildView(old.view); } catch {} }
  activeId = id; win.contentView.addChildView(next.view); layout(); next.view.webContents.focus(); pushNow();
}

function createTab(url) {
  const id = nextId++;
  const view = new WebContentsView({ webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false, webSecurity: true, allowRunningInsecureContent: false, spellcheck: false } });
  const wc = view.webContents;
  const tab = { id, view, title: "New Tab", url: "", loading: false, favicon: null, failedUrl: null, blocked: 0 };
  tabs.set(id, tab); tabByWc.set(wc.id, tab);
  wc.on("page-title-updated", (_e, t) => { tab.title = t; push(); });
  wc.on("page-favicon-updated", (_e, f) => { tab.favicon = f[0]; push(); });
  wc.on("did-start-loading", () => { tab.loading = true; push(); });
  wc.on("did-stop-loading", () => { tab.loading = false; push(); });
  wc.on("did-start-navigation", (d) => { if (d.isMainFrame && !d.isSameDocument) { tab.blocked = 0; } });
  const nav = (_e, u) => {
    if (u.startsWith("file:") && tab.failedUrl) tab.url = tab.failedUrl;
    else { tab.failedUrl = null; tab.url = u; if (u.startsWith("file:")) tab.favicon = null; }
    push();
  };
  wc.on("did-navigate", nav); wc.on("did-navigate-in-page", nav);
  wc.on("did-fail-load", (_e, code, desc, vurl, isMain) => {
    if (!isMain || code === -3) return;
    tab.failedUrl = vurl;
    wc.loadFile(path.join(UI_DIR, "error.html"), { query: { url: vurl, err: desc } });
  });
  const guard = (e, u) => { if (!navAllowed(wc, u)) e.preventDefault(); };
  wc.on("will-navigate", guard); wc.on("will-redirect", guard);
  wc.on("enter-html-full-screen", () => { htmlFull = true; win.setFullScreen(true); layout(); });
  wc.on("leave-html-full-screen", () => { htmlFull = false; win.setFullScreen(false); layout(); });
  wc.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//i.test(url)) createTab(url); return { action: "deny" }; });
  wc.once("destroyed", () => tabByWc.delete(wc.id));
  wc.loadURL(url || page("newtab.html")).catch(() => {});
  activate(id);
}
function closeTab(id) {
  const t = tabs.get(id); if (!t) return;
  const idx = [...tabs.keys()].indexOf(id);
  tabs.delete(id);
  try { win.contentView.removeChildView(t.view); } catch {}
  t.view.webContents.close();
  if (!tabs.size) return createTab();
  if (id === activeId) { activeId = null; activate([...tabs.keys()][Math.min(idx, tabs.size - 1)]); } else push();
}
const cycle = (d) => { const k = [...tabs.keys()]; if (k.length > 1) activate(k[(k.indexOf(activeId) + d + k.length) % k.length]); };
function nav(a) {
  const wc = activeWC(); if (!wc) return; const h = wc.navigationHistory;
  if (a === "back" && h.canGoBack()) h.goBack();
  if (a === "forward" && h.canGoForward()) h.goForward();
  if (a === "reload") wc.reload();
  if (a === "stop") wc.stop();
}
function openAI(url) {
  const origin = new URL(url).origin, hit = [...tabs.values()].find((t) => t.url.startsWith(origin));
  hit ? activate(hit.id) : createTab(url);
}
const zoom = (d) => { const wc = activeWC(); if (wc) wc.setZoomLevel(d === 0 ? 0 : wc.getZoomLevel() + d); };

// ---------- security: network, permissions, downloads ----------
function hardenSession(ses) {
  ses.setSpellCheckerEnabled(false);
  const filter = { urls: ["http://*/*", "https://*/*", "ws://*/*", "wss://*/*"] };
  ses.webRequest.onBeforeRequest(filter, (d, cb) => {
    let u; try { u = new URL(d.url); } catch { return cb({}); }
    if (d.resourceType !== "mainFrame" && isTracker(u.hostname)) {
      const t = tabByWc.get(d.webContentsId); if (t) { t.blocked++; push(); }
      settings.blocked++; saveSoon(); return cb({ cancel: true });
    }
    if (u.protocol === "http:" && !isLocal(u.hostname) && !httpAllow.has(u.hostname)) { u.protocol = "https:"; return cb({ redirectURL: u.href }); }
    cb({});
  });
  ses.webRequest.onBeforeSendHeaders(filter, (d, cb) => { d.requestHeaders["DNT"] = "1"; d.requestHeaders["Sec-GPC"] = "1"; cb({ requestHeaders: d.requestHeaders }); });
  const AUTO = new Set(["fullscreen", "pointerLock", "clipboard-sanitized-write"]);
  const ASK = { media: "camera or microphone", geolocation: "location", notifications: "notifications", "clipboard-read": "clipboard" };
  ses.setPermissionRequestHandler((_wc, perm, cb, details) => {
    if (AUTO.has(perm)) return cb(true);
    if (!ASK[perm]) return cb(false);
    let origin; try { origin = new URL(details.requestingUrl).origin; } catch { return cb(false); }
    if (!origin.startsWith("https:")) return cb(false);
    const key = origin + "|" + perm;
    if (decisions.has(key)) return cb(decisions.get(key));
    dialog.showMessageBox(win, { type: "question", buttons: ["Allow", "Block"], defaultId: 1, cancelId: 1, title: "Permission request", message: `${origin} wants to use your ${ASK[perm]}.`, detail: "Your choice is remembered until you close Leopatro." })
      .then((r) => { const ok = r.response === 0; decisions.set(key, ok); cb(ok); });
  });
  ses.setPermissionCheckHandler((_wc, perm, origin) => AUTO.has(perm) || decisions.get(origin.replace(/\/$/, "") + "|" + perm) === true);
  ses.on("will-download", (_e, item) => {
    const name = item.getFilename();
    if (/\.(exe|msi|bat|cmd|scr|ps1|vbs|jar|com|lnk|dll|reg|hta)$/i.test(name)) {
      const r = dialog.showMessageBoxSync(win, { type: "warning", buttons: ["Cancel", "Download anyway"], defaultId: 0, cancelId: 0, title: "Potentially unsafe file", message: `"${name}" can run code on your computer.`, detail: "From: " + item.getURL() });
      if (r === 0) item.cancel();
    }
  });
}
async function clearData() {
  const r = await dialog.showMessageBox(win, { type: "question", buttons: ["Clear", "Cancel"], defaultId: 1, cancelId: 1, title: "Clear browsing data", message: "Clear cookies, cache and site data?", detail: "You will be signed out of websites." });
  if (r.response !== 0) return;
  await session.defaultSession.clearStorageData(); await session.defaultSession.clearCache(); decisions.clear();
  [...tabs.values()].forEach((t) => t.view.webContents.reload());
}

// ---------- menu ----------
function buildMenu() {
  const ai = C.AI.slice(0, 9).map((a, i) => ({ label: `Open ${a.name}`, accelerator: `CmdOrCtrl+Shift+${i + 1}`, click: () => openAI(a.url) }));
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: "Browser", submenu: [
      { label: "New Tab", accelerator: "CmdOrCtrl+T", click: () => createTab() },
      { label: "Close Tab", accelerator: "CmdOrCtrl+W", click: () => closeTab(activeId) },
      { label: "Next Tab", accelerator: "Ctrl+Tab", click: () => cycle(1) },
      { label: "Previous Tab", accelerator: "Ctrl+Shift+Tab", click: () => cycle(-1) },
      { label: "Address Bar", accelerator: "CmdOrCtrl+L", click: () => win.webContents.send("focus-url") },
      { label: "Reload", accelerator: "CmdOrCtrl+R", click: () => nav("reload") },
      { label: "Reload (F5)", accelerator: "F5", click: () => nav("reload") },
      { label: "Back", accelerator: "Alt+Left", click: () => nav("back") },
      { label: "Forward", accelerator: "Alt+Right", click: () => nav("forward") },
      { label: "Zoom In", accelerator: "CmdOrCtrl+=", click: () => zoom(0.5) },
      { label: "Zoom Out", accelerator: "CmdOrCtrl+-", click: () => zoom(-0.5) },
      { label: "Reset Zoom", accelerator: "CmdOrCtrl+0", click: () => zoom(0) },
      { label: "Clear Browsing Data", accelerator: "CmdOrCtrl+Shift+Delete", click: clearData },
      { label: "Developer Tools", accelerator: "F12", click: () => activeWC()?.toggleDevTools() },
      { label: "Full Screen", accelerator: "F11", role: "togglefullscreen" },
      { label: "About Leopatro", click: () => createTab(page("about.html")) },
      { role: "quit" }
    ] },
    { label: "AI", submenu: ai },
    { role: "editMenu" }
  ]));
}

function createWindow() {
  win = new BrowserWindow({
    width: 1320, height: 820, minWidth: 900, minHeight: 560, title: C.NAME, backgroundColor: "#140c24",
    icon: path.join(__dirname, "build", "icon.png"), titleBarStyle: "hidden",
    titleBarOverlay: { color: "#140c24", symbolColor: "#ececf2", height: TABBAR_H },
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, sandbox: true, spellcheck: false }
  });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (e) => e.preventDefault());
  win.loadFile(path.join(UI_DIR, "index.html"));
  win.on("resize", layoutSoon); win.on("enter-full-screen", layout); win.on("leave-full-screen", layout);
  win.webContents.once("did-finish-load", () => {
    if (!settings.welcomed) { settings.welcomed = true; saveSoon(); createTab(page("welcome.html")); } else createTab();
  });
}

// ---------- IPC (only from our own UI) ----------
const fromUI = (e) => win && e.sender === win.webContents;
ipcMain.handle("config", (e) => fromUI(e) ? { NAME: C.NAME, CREATOR: C.CREATOR, VERSION: C.VERSION, AI: C.AI } : null);
ipcMain.on("tab:new", (e) => fromUI(e) && createTab());
ipcMain.on("tab:close", (e, id) => fromUI(e) && closeTab(id));
ipcMain.on("tab:activate", (e, id) => fromUI(e) && activate(id));
ipcMain.on("nav", (e, a) => fromUI(e) && nav(a));
ipcMain.on("go", (e, text) => {
  if (!fromUI(e) || typeof text !== "string") return;
  if (/^http:\/\//i.test(text.trim())) { try { httpAllow.add(new URL(text.trim()).hostname); } catch {} }
  activeWC()?.loadURL(toURL(text)).catch(() => {});
});
ipcMain.on("open-ai", (e, url) => { if (fromUI(e) && C.AI.some((a) => a.url === url)) openAI(url); });
ipcMain.on("about", (e) => fromUI(e) && createTab(page("about.html")));

app.on("web-contents-created", (_e, c) => c.on("will-attach-webview", (ev) => ev.preventDefault()));
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => { loadSettings(); hardenSession(session.defaultSession); buildMenu(); createWindow(); });
  app.on("before-quit", () => { try { fs.writeFileSync(settingsFile(), JSON.stringify(settings)); } catch {} });
  app.on("window-all-closed", () => app.quit());
}
