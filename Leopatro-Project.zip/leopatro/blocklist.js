// Ad / tracker domains blocked by Leopatro Shields (sub-resources only).
module.exports = new Set([
  "doubleclick.net","googlesyndication.com","googleadservices.com","google-analytics.com",
  "adservice.google.com","googletagservices.com","2mdn.net","adnxs.com","taboola.com","outbrain.com",
  "criteo.com","criteo.net","scorecardresearch.com","quantserve.com","hotjar.com","ads-twitter.com",
  "amazon-adsystem.com","rubiconproject.com","pubmatic.com","openx.net","moatads.com","adsrvr.org",
  "mathtag.com","bat.bing.com","adform.net","casalemedia.com","advertising.com","bidswitch.net",
  "smartadserver.com","teads.tv","yieldmo.com","sharethrough.com","media.net","zedo.com",
  "serving-sys.com","everesttech.net","demdex.net","krxd.net","bluekai.com","adroll.com","tapad.com",
  "mouseflow.com","crazyegg.com","fullstory.com","mixpanel.com","segment.io","clarity.ms"
]);
