// Leopatro by Faqih Corporation.
module.exports = {
  NAME: "Leopatro",
  VERSION: "1.0.0",
  CREATOR: "Faqih Corporation",
  SEARCH: "https://www.google.com/search?q=",
  AI: require("./ui/ai.js")
};
