const $ = (s) => document.querySelector(s);
const tabsEl = $("#tabs"), urlEl = $("#url"), lock = $("#lock"), sec = $("#sec"), shield = $("#shield"), count = $("#count");
const els = new Map();

function makeTab(t) {
  const el = document.createElement("div"), ic = document.createElement("span"), tt = document.createElement("span"), x = document.createElement("button");
  el.className = "tab"; ic.className = "ico blank"; tt.className = "t"; x.className = "x"; x.textContent = "\u00d7"; x.title = "Close tab";
  x.onclick = (e) => { e.stopPropagation(); leo.closeTab(t.id); };
  el.append(ic, tt, x);
  el.onclick = () => leo.activate(t.id);
  el.onauxclick = (e) => { if (e.button === 1) leo.closeTab(t.id); };
  return { el, ic, tt, last: {} };
}
function update(o, t, activeId) {
  const L = o.last, cls = "tab" + (t.id === activeId ? " active" : "");
  if (L.cls !== cls) { o.el.className = cls; L.cls = cls; }
  const title = t.title || "New Tab";
  if (L.title !== title) { o.tt.textContent = title; o.el.title = title; L.title = title; }
  const ik = t.loading ? "spin" : t.favicon || "blank";
  if (L.ik !== ik) {
    L.ik = ik; o.ic.textContent = "";
    if (t.loading) o.ic.className = "ico spin";
    else if (t.favicon) { o.ic.className = "ico"; const im = new Image(); im.src = t.favicon; im.onerror = () => { o.ic.className = "ico blank"; im.remove(); }; o.ic.append(im); }
    else o.ic.className = "ico blank";
  }
}
function render(s) {
  for (const [id, o] of els) if (!s.tabs.some((t) => t.id === id)) { o.el.remove(); els.delete(id); }
  s.tabs.forEach((t, i) => {
    let o = els.get(t.id); if (!o) { o = makeTab(t); els.set(t.id, o); }
    if (tabsEl.children[i] !== o.el) tabsEl.insertBefore(o.el, tabsEl.children[i] || null);
    update(o, t, s.activeId);
  });
  const a = s.tabs.find((t) => t.id === s.activeId);
  if (a) {
    if (document.activeElement !== urlEl) urlEl.value = a.url;
    const https = a.url.startsWith("https:"), http = a.url.startsWith("http:");
    lock.className = "lock " + (https ? "secure" : http ? "warn" : "none");
    sec.textContent = http ? "Not secure" : "";
    count.textContent = a.blocked || 0;
    shield.className = "shield" + (a.blocked ? " on" : "");
    shield.title = `Shields: ${a.blocked || 0} trackers & ads blocked on this page`;
  }
  $("#back").disabled = !s.canBack; $("#forward").disabled = !s.canForward;
}

$("#newtab").onclick = () => leo.newTab();
$("#back").onclick = () => leo.nav("back");
$("#forward").onclick = () => leo.nav("forward");
$("#reload").onclick = () => leo.nav("reload");
$("#about").onclick = () => leo.about();
$("#omni").onsubmit = (e) => { e.preventDefault(); leo.go(urlEl.value); urlEl.blur(); };
urlEl.onfocus = () => urlEl.select();
leo.onFocusUrl(() => { urlEl.focus(); urlEl.select(); });
leo.onState(render);

AI.forEach((a, i) => {
  const b = document.createElement("button"), tile = document.createElement("i"), n = document.createElement("span");
  b.className = "chip"; b.title = `${a.name}  (Ctrl+Shift+${i + 1})`;
  tile.textContent = a.short; tile.style.background = a.bg; tile.style.color = a.fg; n.textContent = a.name;
  b.append(tile, n); b.onclick = () => leo.openAI(a.url); $("#bookmarks").append(b);
});
