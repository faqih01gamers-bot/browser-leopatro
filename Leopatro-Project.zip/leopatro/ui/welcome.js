document.getElementById("no").href = "newtab.html" + location.search;
