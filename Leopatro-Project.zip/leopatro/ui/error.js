const p = new URLSearchParams(location.search), $ = (i) => document.getElementById(i);
$("u").textContent = p.get("url") || "";
$("e").textContent = (p.get("err") || "").replace(/^ERR_/, "").replace(/_/g, " ").toLowerCase();
$("r").onclick = () => { if (p.get("url")) location.href = p.get("url"); };
