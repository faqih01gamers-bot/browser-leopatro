const p = new URLSearchParams(location.search), $ = (i) => document.getElementById(i);
$("by").textContent = p.get("creator") || "Faqih Corporation";
$("v").textContent = "v" + (p.get("v") || "1.0.0");
$("blocked").textContent = Number(p.get("blocked") || 0).toLocaleString("en-US");
for (const a of AI) {
  const l = document.createElement("a"), b = document.createElement("b"), s = document.createElement("span");
  l.className = "card"; l.href = a.url; b.textContent = a.short; b.style.background = a.bg; b.style.color = a.fg; s.textContent = a.name;
  l.append(b, s); $("grid").append(l);
}
let last = "";
const tick = () => { const t = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }); if (t !== last) { last = t; $("clock").textContent = t; } };
tick(); setInterval(tick, 1000);
$("f").onsubmit = (e) => {
  e.preventDefault(); const v = $("q").value.trim(); if (!v) return;
  location.href = /^https?:\/\//i.test(v) ? v : (!/\s/.test(v) && /^[^\s]+\.[^\s.]{2,}(\/.*)?$/.test(v)) ? "https://" + v : "https://www.google.com/search?q=" + encodeURIComponent(v);
};
