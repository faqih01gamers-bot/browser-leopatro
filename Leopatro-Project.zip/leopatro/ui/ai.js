// Single source of truth for the AI shortcuts (used by main process and UI pages).
const AI = [
  { name: "Claude",     url: "https://claude.ai",                short: "Cl", bg: "#d97757", fg: "#1a0f0a" },
  { name: "ChatGPT",    url: "https://chatgpt.com",              short: "Gp", bg: "#10a37f", fg: "#04150f" },
  { name: "Gemini",     url: "https://gemini.google.com",        short: "Ge", bg: "#7c9cff", fg: "#0a1233" },
  { name: "Grok",       url: "https://grok.com",                 short: "Gk", bg: "#e9e9ee", fg: "#101014" },
  { name: "Perplexity", url: "https://www.perplexity.ai",        short: "Px", bg: "#22b8cf", fg: "#04181c" },
  { name: "Copilot",    url: "https://copilot.microsoft.com",    short: "Co", bg: "#8b7bff", fg: "#0d0a26" },
  { name: "DeepSeek",   url: "https://chat.deepseek.com",        short: "Ds", bg: "#4d6bfe", fg: "#ffffff" },
  { name: "Le Chat",    url: "https://chat.mistral.ai",          short: "Lc", bg: "#fa6a1e", fg: "#1c0a02" }
];
if (typeof module !== "undefined") module.exports = AI;
