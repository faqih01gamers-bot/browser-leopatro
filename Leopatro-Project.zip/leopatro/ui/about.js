const p = new URLSearchParams(location.search);
for (const id of ["by", "by2"]) document.getElementById(id).textContent = p.get("creator") || "Faqih Corporation";
document.getElementById("v").textContent = p.get("v") || "1.0.0";
