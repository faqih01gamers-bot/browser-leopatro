const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("leo", {
  config: () => ipcRenderer.invoke("config"),
  newTab: () => ipcRenderer.send("tab:new"),
  closeTab: (id) => ipcRenderer.send("tab:close", id),
  activate: (id) => ipcRenderer.send("tab:activate", id),
  nav: (a) => ipcRenderer.send("nav", a),
  go: (t) => ipcRenderer.send("go", t),
  openAI: (u) => ipcRenderer.send("open-ai", u),
  about: () => ipcRenderer.send("about"),
  onState: (cb) => ipcRenderer.on("state", (_e, s) => cb(s)),
  onFocusUrl: (cb) => ipcRenderer.on("focus-url", () => cb())
});
