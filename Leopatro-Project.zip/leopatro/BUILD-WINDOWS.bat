@echo off
title Build Leopatro Setup
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js belum terpasang. Install versi LTS dari https://nodejs.org lalu jalankan file ini lagi.
  pause
  exit /b 1
)
echo [1/2] Menginstall komponen...
call npm install
if errorlevel 1 goto gagal
echo [2/2] Membuat installer...
call npm run dist
if errorlevel 1 goto gagal
echo.
echo SELESAI. Installer ada di folder "dist": Leopatro-Setup-1.0.0.exe
start "" "%~dp0dist"
pause
exit /b 0
:gagal
echo.
echo Gagal. Cek pesan error di atas.
pause
exit /b 1
