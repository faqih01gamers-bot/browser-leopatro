# Leopatro  -  by Faqih Corporation

A fast, private Chromium-based browser (Electron) with Brave-style Shields and AI shortcuts:
Claude, ChatGPT, Gemini, Grok, Perplexity, Copilot, DeepSeek, Le Chat.

## Build the Windows installer (setup .exe)
A) Easiest: double-click `BUILD-WINDOWS.bat` (needs Node.js LTS). Result: `dist/Leopatro-Setup-1.0.0.exe`
B) Manual:  npm install  ->  npm start (test)  ->  npm run dist
C) No install: upload this folder to a GitHub repo (branch `main`), open Actions ->
   "Build Leopatro Setup" -> Run workflow, then download the artifact.
SmartScreen warns on unsigned installers until you sign with a code-signing certificate.

## Features
- First launch asks: "Do you want to sign in to Google?"
- Shields: blocks ad/tracker domains, upgrades http to https, sends DNT + Global Privacy Control
- Permission prompts for camera/mic/location/notifications (denied by default for everything else)
- Warning before downloading executables (.exe, .msi, .bat ...)
- Sandboxed tabs, blocked non-web protocols, IPC accepted only from the browser UI
- Ctrl+Shift+Del clears cookies/cache; Ctrl+Shift+1..8 opens an AI; F12 devtools

## Customize
- AI shortcuts: edit `ui/ai.js`
- Ad/tracker list: edit `blocklist.js`
- Name/credits: `config.js`, `package.json`, `build/license.txt`
